using System;

namespace DeckOfCards
{
    class Card
    {
        //=============== Attributes up top ================//
        public string stringVal;
        public string suit;
        public int val;
        //================= Constructor(s) =================//
        public Card(string suit, int val)
        {
            stringVal = val + " of " + suit;
            suit = suit;
            val = val;
        }
        //==================== Methods =====================//
    }
}