﻿using System;

namespace HungryNinja
{
    class Program
    {
        static void Main(string[] args)
        {
            Ninja Tyler = new Ninja("Tyler");
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            Tyler.Eat();
            System.Console.WriteLine(Tyler.CalorieIntake);
        }
    }
}
