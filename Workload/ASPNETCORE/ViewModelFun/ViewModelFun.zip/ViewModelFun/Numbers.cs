// namespace ViewModelFun
// {
//     public class Numbers
//     {
//         public array Numbers()
//         {

//             retrurn arr
//         }
//     }
// }