namespace Portfolio2
{
    public class Project
    {
        public string name;
        public string desc;
        public string urlLocation;
        public Project(string name, string desc, string urlLocation)
        {
            this.name = name;
            this.desc = desc;
            this.urlLocation = urlLocation;
        }
    }
}
